package common.com.paypal.platform.sdk.exceptions;

public class SSLConnectionException extends Exception {

	public SSLConnectionException() {
		// TODO Auto-generated constructor stub
	}

	public SSLConnectionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SSLConnectionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SSLConnectionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
